export const SourceSettings = {
  sourceBaseUri: 'https://api.na4.adobesign.com/api/rest/v6/',
  sourceIntegrationKey: '3AAABLblqZhDI08CVbG5A7glf8jxmrdoIyo0RZlchGBQhex8Jw1WNuoZiuIXlrLe89BlaxYtEdUka-I8zQ_xugtxcHO5WxP7k'
}
