export const DestinationSettings = {
  destinationBaseUri: 'url goes here',
  destinationIntegrationKey: 'key goes here'
}

