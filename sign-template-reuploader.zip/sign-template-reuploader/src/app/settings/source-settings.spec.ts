import { SourceSettings } from './source-settings';

describe('SourceSettings', () => {
  it('should create an instance', () => {
    expect(new SourceSettings()).toBeTruthy();
  });
});
