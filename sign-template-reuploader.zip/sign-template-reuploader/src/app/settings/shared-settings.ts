export const SharedSettings = {

}
