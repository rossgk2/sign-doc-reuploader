import { DestinationSettings } from './destination-settings';

describe('DestinationSettings', () => {
  it('should create an instance', () => {
    expect(new DestinationSettings()).toBeTruthy();
  });
});
