import { SharedSettings } from './shared-settings';

describe('AppSettings', () => {
  it('should create an instance', () => {
    expect(new SharedSettings()).toBeTruthy();
  });
});
