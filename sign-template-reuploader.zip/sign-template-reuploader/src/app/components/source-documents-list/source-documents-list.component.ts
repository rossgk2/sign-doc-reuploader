import {Component, OnInit} from '@angular/core';
import {FormArray, FormBuilder, FormGroup, FormControl, Validators} from '@angular/forms';
import {DownloadService} from '../../services/download.service';

@Component({
  selector: 'app-source-documents-list',
  templateUrl: './source-documents-list.component.html',
  styleUrls: ['./source-documents-list.component.scss']
})
export class SourceDocumentsListComponent implements OnInit {


  documentListForm = this.formBuilder.group({
    documents: this.formBuilder.array([])
  });

  readyForDownload: boolean = false;

  constructor(private formBuilder: FormBuilder,
              private downloadService: DownloadService) {
  }

  get documents() {
    return this.documentListForm.controls['documents'] as FormArray;
  }

  populateDocForm(documentData: any) {

    this.readyForDownload = true;
    documentData.forEach(template => {
      const documentForm = this.formBuilder.group({
        name: [template.name],
        include: ['']
      });
      this.documents.push(documentForm);
    });

  }

  getDocumentList(): void {

    let documentsCall = this.downloadService.getAllDocuments();
    console.log('starting call, mang! hold on a you asses!');

    documentsCall.subscribe(data => {
      console.log('we gots a thing, mang', data);
      if (data.status === 200) {
        console.log('shit was successful, mang! time a getta beer!');
        this.populateDocForm(data.body.libraryDocumentList);
      }
    }, error => {
      console.log('oh no we hit a iceberg! ahhhhhhhhh!', error);
    });

  }

  beginUpload() {
    console.log('we ain\'t ready for this one, mang. come back later and go have a you a beer');
  }

  ngOnInit() {
  }

}
